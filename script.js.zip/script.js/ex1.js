//1. Configuração do Ambiente

console.log("Ambiente configurado com sucesso!");