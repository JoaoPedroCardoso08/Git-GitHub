//2. Trabalhando com Variáveis e Tipos de Dados
let nome = "Cardoso";
let idade = 17;
let altura = 1.65;
let programador = true;

let anoNascimento = 2008;
let anoNascimento1 = String(anoNascimento);
console.log(anoNascimento1, typeof anoNascimento1);

let peso = "75";
let peso1 = Number(peso);
console.log(peso1, typeof peso1);
