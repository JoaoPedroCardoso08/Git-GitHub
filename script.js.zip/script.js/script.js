const prompt = require("prompt-sync")();

//1. Configuração do Ambiente
console.log("Ambiente configurado com sucesso!");

//2. Trabalhando com Variáveis e Tipos de Dados
let nome = "Cardoso";
let idade = 17;
let altura = 1.65;
let programador = true;

let anoNascimento = 2008;
let anoNascimento1 = Number(anoNascimento);
console.log(anoNascimento1, typeof anoNascimento1);

let peso = "75";
let peso1 = Number(peso);
console.log(peso1, typeof peso1);

//3. Estruturas Condicionais
let Numero = Number(prompt("Informe o numero:"));
if (Numero % 2 === 0) {
  console.log("Par");
} else {
  console.log("Impar");
}

let numero3 = Number(prompt("Informe o numero:"));
let numero4 = Number(prompt("Informe o numero:"));

console.log(numero3 + numero4);
console.log(numero3 - numero4);
console.log(numero3 * numero4);
console.log(numero3 / numero4);

let numero7 = Number(prompt("Informe a sua idade:"));
console.log(idade > 18 && idade < 30); 
console.log(idade < 18 || idade > 65); 
console.log(!false); 



//4. Estruturas de Repetição
let contador = 1;
while (contador <= 10) {
  console.log("Contador:", contador);
  contador++;
}

let numero1 = Number(prompt("Informe o numero:"));
let numero2 = 0;
for (let i = 1; i <= 10; i++) {
  numero2 += numero1;
  console.log(`${numero1} x ${i} = ${numero2}`);
}

let contador1 = 10;
while (contador1 >= 1) {
    console.log("Contador:", contador1);
    contador1--;
}
console.log("Feliz Ano Novo!");

//5. Funções
function boasVindas(nome) {
    return console.log("Olá,", nome,"Sejá bem-vindo(a)");
}
let nome1 = prompt("Digite seu nome: ")
console.log(boasVindas(nome1))

let numero5 = Number(prompt("Informe o numero:"));
let numero6 = Number(prompt("Informe o numero:"));